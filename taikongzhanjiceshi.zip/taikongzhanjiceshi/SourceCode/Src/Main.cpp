//-----------------------------------------------------------------------------
//
//-----------------------------------------------------------------------------
#include "CommonAPI.h"
#include "LessonX.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define N 10000
//////////////////
float g_fSpeedUp = 0.f;
float g_fSpeedDown = 0.f;
float g_fSpeedLeft = 0.f;
float g_fSpeedRight = 0.f;
float g_zuosudu=1;
float g_yousudu=1;
float g_shangsudu=1;
float g_xiasudu=1;
int g_iNum = 0;
int xiaozidannum=0;
int zhongzidannum=0;
int dazidannum=0;
int g_youiCount=0;
int g_zidandaxiao=1;
float g_youxishijiantime=0.f;
int g_iCount = 0;
int g_wuiCount=0;
int g_suijishu=0;
int g_iGameStates=-1;
int g_iGameScore;
int g_renwusiwang=1;
float g_fBaseTime[6]={0.5,1.5,60.0,120.0,200.0,20.0};
float g_fCurrentTime[6]={0.5,1.5,60.0,120.0,200.0,20.0};
float g_zidanchongfushijian=2.0f;
float g_zidanchongzhi=2.0f;
float  g_zidanchongfushijianda=2.0f;
float g_zidanchongzhida=2.0f;
float fPosX,fPosY,FposX,FposY,FPosX,FPosY,FpOsX;
int i=0;
int x=0,z=0,d=0;
float chusudu=10.f;
int scorenum=0;
int xiaobossxue=700;
int zhongbossxue=1200;
int dabossxue=2000;
//���ַɵ��ļ��ʱ
char *g_szType[5] = {"wuzidan_muban","youzidan_muban","xiaoboss","zhongboss","daboss"};
char *SZNAME;///////////////////////////////////////////////////////////////////////////////
//
// ���������
//
//////////////////////////////////////////////////////////////////////////////////////////
int PASCAL WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR     lpCmdLine,
                   int       nCmdShow)
{
	// ��ʼ����Ϸ����
	if( !dInitGameEngine( hInstance, lpCmdLine ) )
		return 0;

	// To do : �ڴ�ʹ��API���Ĵ��ڱ���
	dSetWindowTitle("Lesson");
     dShowCursor(false);	//�ڴ������������
     int countdown=7;
     float countPassedTime=0.f;
     dSetSpriteVisible("countdown",false);
     float fScreenLeft = dGetScreenLeft();
	float fScreenRight = dGetScreenRight() ;
	float fScreenTop = dGetScreenTop() ;
	// ������ѭ����������Ļͼ��ˢ�µȹ���
	while( dEngineMainLoop() )
	{
		// ��ȡ���ε���֮���ʱ�����ݸ���Ϸ�߼�����
		float	fTimeDelta	=	dGetTimeDelta();
        if(g_iGameStates==1)
{
	countPassedTime += fTimeDelta;	//ͳ�ƾ�����ʱ�䣬���洢��countPassedTime
	dSetTextValue("countdown",countdown -countPassedTime);
	 dSetSpriteVisible("kaishimap",true);
	 if(countPassedTime >=5.0f) dSetSpriteVisible("kaishimap",false);
	if(countPassedTime >= countdown)
{
//������ʱ�䳬��countdown
		dSetSpriteVisible("countdown",false);
		dSetSpritePosition("zhanji",0,25);
		dSetSpriteVisible("xiaoboss",false);
		dSetSpriteVisible("zhongboss",false);
		dSetSpriteVisible("daboss",false);
		x=0,z=0,d=0;	//����countdown
		countPassedTime = 0;//���þ�����ʱ�䣬Ϊ��һ����Ϸ��׼��
		g_iGameStates = 2;
        g_youxishijiantime=0;//�л�g_iGameState 12
        g_fCurrentTime[2]=60.0;
        g_fCurrentTime[3]=120.0;
        g_fCurrentTime[4]=200.0;
        g_fCurrentTime[5]=20.0;
        xiaozidannum=0;
        zhongzidannum=0;
        dazidannum=0;
        g_iNum=0;
	}
}
        if(g_iGameStates==2)
    {
            fPosX = dGetSpriteLinkPointPosX("zhanji",1);
		fPosY = dGetSpriteLinkPointPosY("zhanji",1);
            g_youxishijiantime+=fTimeDelta;
            dSetTextValue("score",scorenum);
            dSetTextValue("time",g_youxishijiantime);
        FposY = fScreenTop - 5.f;
        if(g_youxishijiantime>=0&&g_youxishijiantime<=400)
        {
            g_fCurrentTime[0] -= fTimeDelta;
            if(g_fCurrentTime[0] <= 0)
            {
              char *SzName;
           g_fCurrentTime[0]=g_fBaseTime[0];
           FposX=dRandomRange(fScreenLeft + 5, fScreenRight - 5);
            SzName=dMakeSpriteName("wuzidan",g_wuiCount++);
		//��ô������ӵ�λ�ã���Ϊ�ڵ����
		dCloneSprite(g_szType[0],SzName);
		dSetSpritePosition(SzName,FposX, FposY);
		dSpriteMoveTo(SzName,fPosX,fPosY,20,false);
            }
        }



        if(g_youxishijiantime>=0&&g_youxishijiantime<=400)
    {
           g_fCurrentTime[1] -= fTimeDelta;
            if(g_fCurrentTime[1] <= 0)
        {
                g_fCurrentTime[1] =g_fBaseTime[1];
                char *SzName11;
           char fposx1;
           fposx1=dRandomRange(fScreenLeft + 5, fScreenRight - 5);
            SzName11=dMakeSpriteName("youzidan",g_wuiCount++);
		//��ô������ӵ�λ�ã���Ϊ�ڵ����
		dCloneSprite("youzidan_muban",SzName11);
		dSetSpritePosition(SzName11,fposx1, FposY);
		dSpriteMoveTo(SzName11,fPosX,fPosY,40,false);
        }
    }
    if(g_youxishijiantime>=0&&g_youxishijiantime<=90)
   {
        g_fCurrentTime[2] -= fTimeDelta;
            if(g_fCurrentTime[2] <= 0)
    {
                g_fCurrentTime[2]=g_fBaseTime[2];
                x=1;xiaobossxue=500;
		dSetSpritePosition("xiaoboss",0,-25);
		dSetSpriteVisible("xiaoboss",true);
         dSetSpriteLinearVelocity ("xiaoboss",15,0);
         dSetSpriteWorldLimitMode("xiaoboss", WORLD_LIMIT_NULL);
     }
   }
    if(g_youxishijiantime>=0&&g_youxishijiantime<=150)
   {
        g_fCurrentTime[3] -= fTimeDelta;
            if(g_fCurrentTime[3] <= 0)
    {
                g_fCurrentTime[3]=g_fBaseTime[3];
                z=1;zhongbossxue=1200;
		dSetSpritePosition("zhongboss",0,-25);
		dSetSpriteVisible("zhongboss",true);
         dSetSpriteLinearVelocity ("zhongboss",13,0);
         dSetSpriteWorldLimitMode("zhongboss", WORLD_LIMIT_NULL);
     }
   }
    if(g_youxishijiantime>=0&&g_youxishijiantime<=230)
   {
        g_fCurrentTime[4] -= fTimeDelta;
        if(g_fCurrentTime[4] <=5)
        {
            dSetSpriteVisible("jinggao",true);
        }
            if(g_fCurrentTime[4] <= 0)
    {
                dSetSpriteVisible("jinggao",false);
                g_fCurrentTime[4]=g_fBaseTime[4];
                d=1;dabossxue=1500;
		dSetSpritePosition("daboss",0,-25);
		dSetSpriteVisible("daboss",true);
         dSetSpriteLinearVelocity ("daboss",10,0);
         dSetSpriteWorldLimitMode("daboss", WORLD_LIMIT_NULL);
     }
   }
    if(g_youxishijiantime>=0&&g_youxishijiantime<=400)
    {
        g_fCurrentTime[5] -= fTimeDelta;
            if(g_fCurrentTime[5] <= 0)
            {
                g_fCurrentTime[5]=g_fBaseTime[5];
        FposX=dRandomRange(fScreenLeft+5, fScreenRight-5);
        char *SzName;
        SzName=dMakeSpriteName("jiaqiang",1);
		//��ô������ӵ�λ�ã���Ϊ�ڵ����
		dCloneSprite("jiaqiang_muban",SzName);
        int hengzuobiao=dRandomRange(0,150);
        dSetSpritePosition(SzName,FposX,FposY);
		dSpriteMoveTo(SzName,hengzuobiao-70,100,20,false);
             }
    }
    if(x==1)
    {
        g_zidanchongfushijian-=fTimeDelta;
		if(g_zidanchongfushijian<=0)
        {
            g_zidanchongfushijian=g_zidanchongzhi;
            char *SZName,*sznamE,*szname1,*szname2;
            SZName = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            sznamE = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);	//�õ��ڵ�����
            szname1 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname2 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
		dCloneSprite("difangxiaozidan_muban",SZName);
		dCloneSprite("difangxiaozidan_muban",sznamE);
		dCloneSprite("difangxiaozidan_muban",szname1);
		dCloneSprite("difangxiaozidan_muban",szname2);
		float fposy1=dGetSpriteLinkPointPosY("xiaoboss",1);
		float fposx1=dGetSpriteLinkPointPosX("xiaoboss",1);
		float fposy2=dGetSpriteLinkPointPosY("xiaoboss",2);
		float fposx2=dGetSpriteLinkPointPosX("xiaoboss",2);
		float fposy3=dGetSpriteLinkPointPosY("xiaoboss",3);
		float fposx3=dGetSpriteLinkPointPosX("xiaoboss",3);
		float fposy4=dGetSpriteLinkPointPosY("xiaoboss",4);
		float fposx4=dGetSpriteLinkPointPosX("xiaoboss",4);
            dSetSpritePosition(SZName,fposx1,fposy1);
            dSetSpritePosition(sznamE,fposx2,fposy2);
            dSetSpritePosition(szname1,fposx3,fposy3);
            dSetSpritePosition(szname2,fposx4,fposy4);
            dSpriteMoveTo(SZName,fPosX+1.0,fPosY+1.0,20,false);
            dSpriteMoveTo( sznamE,fPosX-1.0f,fPosY-1.0f,20,false);
            dSpriteMoveTo( szname1,fPosX+2.0f,fPosY+2.0f,20,false);
            dSpriteMoveTo( szname2,fPosX-2.0f,fPosY-2.0f,20,false);
        }
    }
   if(z==1)
    {
        g_zidanchongfushijian-=fTimeDelta;
		if(g_zidanchongfushijian<=0)
        {
            g_zidanchongfushijian=g_zidanchongzhi;
            char *SZName,*sznamE,*sznaMe,*szname1,*szname2,*szname3,*szname4;
            SZName = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);
            sznamE = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);
            sznaMe = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);	//�õ��ڵ�����
            szname1 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname2 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname3 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname4 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
		dCloneSprite("difangzhongzidan_muban",SZName);
		dCloneSprite("difangzhongzidan_muban",sznamE);
		dCloneSprite("difangzhongzidan_muban",sznaMe);
		dCloneSprite("difangxiaozidan_muban",szname1);
		dCloneSprite("difangxiaozidan_muban",szname2);
		dCloneSprite("difangxiaozidan_muban",szname3);
		dCloneSprite("difangxiaozidan_muban",szname4);
		float fposy=dGetSpriteLinkPointPosY("zhongboss",1);
		float fposx=dGetSpriteLinkPointPosX("zhongboss",1);
		float fposy1=dGetSpriteLinkPointPosY("zhongboss",2);
		float fposx1=dGetSpriteLinkPointPosX("zhongboss",2);
		float fposy2=dGetSpriteLinkPointPosY("zhongboss",3);
		float fposx2=dGetSpriteLinkPointPosX("zhongboss",3);
		float fposy3=dGetSpriteLinkPointPosY("zhongboss",4);
		float fposx3=dGetSpriteLinkPointPosX("zhongboss",4);
		float fposy4=dGetSpriteLinkPointPosY("zhongboss",5);
		float fposx4=dGetSpriteLinkPointPosX("zhongboss",5);
		float fposy5=dGetSpriteLinkPointPosY("zhongboss",6);
		float fposx5=dGetSpriteLinkPointPosX("zhongboss",6);
		float fposy6=dGetSpriteLinkPointPosY("zhongboss",7);
		float fposx6=dGetSpriteLinkPointPosX("zhongboss",7);
            dSetSpritePosition(SZName,fposx,fposy);
            dSetSpritePosition(sznamE,fposx1,fposy1);
            dSetSpritePosition(sznaMe,fposx2,fposy2);
            dSetSpritePosition(szname1,fposx3,fposy3);
            dSetSpritePosition(szname2,fposx4,fposy4);
            dSetSpritePosition(szname3,fposx5,fposy5);
            dSetSpritePosition(szname4,fposx6,fposy6);
            dSpriteMoveTo(SZName,fPosX,fPosY,20,false);
            dSpriteMoveTo( sznamE,fPosX+1.0f,fPosY+1.0f,20,false);
            dSpriteMoveTo( sznaMe,fPosX-1.0f,fPosY-1.0f,20,false);
            dSpriteMoveTo( szname1,fPosX+2.0f,fPosY+2.0f,20,false);
            dSpriteMoveTo( szname2,fPosX-2.0f,fPosY-2.0f,20,false);
            dSpriteMoveTo( szname3,fPosX+3.0f,fPosY+3.0f,20,false);
            dSpriteMoveTo( szname4,fPosX-3.0f,fPosY-3.0f,20,false);
        }
    }
      if(d==1)
    {
        g_zidanchongfushijianda-=fTimeDelta;
		if(g_zidanchongfushijianda<=0)
        {
            g_zidanchongfushijianda=g_zidanchongzhida;
            char *SZName,*sznamE,*sznaMe,*sznAme,*sznaME,*szname1,*szname2,*szname3,*szname4,*szname5,*szname6;
            SZName = dMakeSpriteName("difangdazidan_%d", dazidannum++);
            sznamE = dMakeSpriteName("difangdazidan_%d", dazidannum++);
            sznaMe = dMakeSpriteName("difangdazidan_%d", dazidannum++);
            sznAme = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);
            sznaME = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);	//�õ��ڵ�����
            szname1 = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);
            szname2 = dMakeSpriteName("difangzhongzidan_%d", zhongzidannum++);
            szname3 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname4 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname5 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
            szname6 = dMakeSpriteName("difangxiaozidan_%d", xiaozidannum++);
		dCloneSprite("difangdazidan_muban",SZName);
		dCloneSprite("difangdazidan_muban",sznamE);
		dCloneSprite("difangdazidan_muban",sznaMe);
		dCloneSprite("difangzhongzidan_muban",sznAme);
		dCloneSprite("difangzhongzidan_muban",sznaME);
		dCloneSprite("difangzhongzidan_muban",szname1);
		dCloneSprite("difangzhongzidan_muban",szname2);
		dCloneSprite("difangxiaozidan_muban",szname3);
		dCloneSprite("difangxiaozidan_muban",szname4);
		dCloneSprite("difangxiaozidan_muban",szname5);
		dCloneSprite("difangxiaozidan_muban",szname6);
		float fposy=dGetSpriteLinkPointPosY("daboss",1);
		float fposx=dGetSpriteLinkPointPosX("daboss",1);
		float fposy1=dGetSpriteLinkPointPosY("daboss",2);
		float fposx1=dGetSpriteLinkPointPosX("daboss",2);
		float fposy2=dGetSpriteLinkPointPosY("daboss",3);
		float fposx2=dGetSpriteLinkPointPosX("daboss",3);
		float fposy3=dGetSpriteLinkPointPosY("daboss",4);
		float fposx3=dGetSpriteLinkPointPosX("daboss",4);
		float fposy4=dGetSpriteLinkPointPosY("daboss",5);
		float fposx4=dGetSpriteLinkPointPosX("daboss",5);
		float fposy5=dGetSpriteLinkPointPosY("daboss",6);
		float fposx5=dGetSpriteLinkPointPosX("daboss",6);
		float fposy6=dGetSpriteLinkPointPosY("daboss",7);
		float fposx6=dGetSpriteLinkPointPosX("daboss",7);
		float fposy7=dGetSpriteLinkPointPosY("daboss",8);
		float fposx7=dGetSpriteLinkPointPosX("daboss",8);
		float fposy8=dGetSpriteLinkPointPosY("daboss",9);
		float fposx8=dGetSpriteLinkPointPosX("daboss",9);
		float fposy9=dGetSpriteLinkPointPosY("daboss",10);
		float fposx9=dGetSpriteLinkPointPosX("daboss",10);
		float fposy10=dGetSpriteLinkPointPosY("daboss",11);
		float fposx10=dGetSpriteLinkPointPosX("daboss",11);
            dSetSpritePosition(SZName,fposx,fposy);
            dSetSpritePosition(sznamE,fposx1,fposy1);
            dSetSpritePosition(sznaMe,fposx2,fposy2);
            dSetSpritePosition(sznAme,fposx3,fposy3);
            dSetSpritePosition(sznaME,fposx4,fposy4);
            dSetSpritePosition(szname1,fposx5,fposy5);
            dSetSpritePosition(szname2,fposx6,fposy6);
            dSetSpritePosition(szname3,fposx7,fposy7);
            dSetSpritePosition(szname4,fposx8,fposy8);
            dSetSpritePosition(szname5,fposx9,fposy9);
            dSetSpritePosition(szname6,fposx10,fposy10);
            dSpriteMoveTo(SZName,fPosX,fPosY,20,false);
            dSpriteMoveTo( sznamE,fPosX+1.0f,fPosY+1.0f,20,false);
            dSpriteMoveTo( sznaMe,fPosX-1.0f,fPosY-1.0f,20,false);
            dSpriteMoveTo( sznAme,fPosX+2.0f,fPosY+2.0f,20,false);
            dSpriteMoveTo( sznaME,fPosX-2.0f,fPosY-2.0f,20,false);
            dSpriteMoveTo( szname1,fPosX+3.0f,fPosY+3.0f,20,false);
            dSpriteMoveTo( szname2,fPosX-3.0f,fPosY-3.0f,20,false);
            dSpriteMoveTo( szname3,fPosX+4.0f,fPosY+4.0f,20,false);
            dSpriteMoveTo( szname4,fPosX-4.0f,fPosY-4.0f,20,false);
            dSpriteMoveTo( szname5,fPosX+5.0f,fPosY+5.0f,20,false);
            dSpriteMoveTo( szname6,fPosX-5.0f,fPosY-5.0f,20,false);
        }
    }
}
		// ִ����Ϸ��ѭ��
		GameMainLoop( fTimeDelta );
};

	// �ر���Ϸ����
	dShutdownGameEngine();
	return 0;
}

//==========================================================================
//
// ���沶׽����ƶ���Ϣ�󣬽����õ�������
// ���� fMouseX, fMouseY��Ϊ��굱ǰ����
//
void dOnMouseMove( const float fMouseX, const float fMouseY )
{
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnMouseMove(fMouseX, fMouseY );
}
//==========================================================================
//
// ���沶׽�������Ϣ�󣬽����õ�������
// ���� iMouseType����갴��ֵ���� enum MouseTypes ����
// ���� fMouseX, fMouseY��Ϊ��굱ǰ����
//
void dOnMouseClick( const int iMouseType, const float fMouseX, const float fMouseY )
{
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnMouseClick(iMouseType, fMouseX, fMouseY);

}
//==========================================================================
//
// ���沶׽��굯����Ϣ�󣬽����õ�������
// ���� iMouseType����갴��ֵ���� enum MouseTypes ����
// ���� fMouseX, fMouseY��Ϊ��굱ǰ����
//
void dOnMouseUp( const int iMouseType, const float fMouseX, const float fMouseY )
{
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnMouseUp(iMouseType, fMouseX, fMouseY);

}
//==========================================================================
//
// ���沶׽���̰�����Ϣ�󣬽����õ�������
// ���� iKey�������µļ���ֵ�� enum KeyCodes �궨��
// ���� iAltPress, iShiftPress��iCtrlPress�������ϵĹ��ܼ�Alt��Ctrl��Shift��ǰ�Ƿ�Ҳ���ڰ���״̬(0δ���£�1����)
//
void dOnKeyDown( const int iKey, const int iAltPress, const int iShiftPress, const int iCtrlPress )
{
    if(KEY_ENTER==iKey&&g_iGameStates==-1)
    {
       dSetSpriteVisible("kaishimap",true);
       dSetSpriteVisible("chongxinkaishi",false);
       g_iGameStates=0;
       dSetSpriteVisible("shengli",false);
       dSetSpriteVisible("jinggao",false);
    }
    if( KEY_SPACE == iKey && 0 ==  g_iGameStates )
	{
		g_iGameStates =	1;
		dSetSpriteVisible("kaishi",false);
		dSetSpriteVisible("countdown",true);
		dSetSpriteVisible("zhanji",true);
		scorenum = 0;			//��ʼ����һ����Ϸ����
		g_youxishijiantime=0.f;		//��ʼ����һ����Ϸʱ��
		dSetTextValue("Score",g_iGameScore);
		dSetTextValue("Time",g_youxishijiantime);
		dSetSpriteVisible("xiaoboss",false);
        dSetSpriteVisible("zhongboss",false);
        dSetSpriteVisible("daboss",false);
        dSetSpritePosition("zhanji",0,25);
        g_zidandaxiao=1;
	}
	if(g_iGameStates==2)
    {
	switch(iKey)
	{
	case KEY_W:
	    if(g_shangsudu!=0)
        {
            g_fSpeedUp = -10.f;
            g_xiasudu=1;
        }
            break;
	case KEY_A:
	    if(g_zuosudu!=0)
        {
            g_fSpeedLeft = -10.f;
            g_yousudu=1;
        }
            break;
	case KEY_S:
	    if(g_xiasudu!=0)
        {
        g_fSpeedDown = 10.f;
        g_shangsudu=1;
        }
		break;
	case KEY_D:
	    if(g_yousudu!=0)
        {
        g_fSpeedRight = 10.f;
        g_zuosudu=1;
        }
		break;
	}
	if(iKey==KEY_K)
    {
		//��ô������ӵ�λ�ã���Ϊ�ڵ����
		fPosX = dGetSpriteLinkPointPosX("zhanji",1);
		fPosY = dGetSpriteLinkPointPosY("zhanji",1);
		char *szName;
		if(g_zidandaxiao==1)
        {
            szName = dMakeSpriteName("xiaopao_%d", g_iNum++);		//�õ��ڵ�����
		dCloneSprite("xiaopao_muban",szName);		//�����ڵ�ģ��
		dSetSpritePosition(szName,fPosX, fPosY);
		dSpriteMoveTo(szName,fPosX,fPosY-100,30,false);
        }
		else if(g_zidandaxiao==2)
        {
            szName = dMakeSpriteName("zhongpao_%d", g_iNum++);		//�õ��ڵ�����
		dCloneSprite("zhongpao_muban",szName);		//�����ڵ�ģ��
		dSetSpritePosition(szName,fPosX, fPosY);
		dSpriteMoveTo(szName,fPosX,fPosY-100,30,false);
        }
        else if(g_zidandaxiao==3)
        {
            szName = dMakeSpriteName("dapao_%d", g_iNum++);		//�õ��ڵ�����
		dCloneSprite("dapao_muban",szName);		//�����ڵ�ģ��
		dSetSpritePosition(szName,fPosX, fPosY);
		dSpriteMoveTo(szName,fPosX,fPosY-100,30,false);
        }
        else if(g_zidandaxiao==4)
        {
        szName = dMakeSpriteName("qiangpao_%d", g_iNum++);		//�õ��ڵ�����
		dCloneSprite("qiangpao_muban",szName);		//�����ڵ�ģ��
		dSetSpritePosition(szName,fPosX, fPosY);
		dSpriteMoveTo(szName,fPosX,fPosY-100,30,false);
		szName = dMakeSpriteName("xiaopao_%d", g_iNum++);		//�õ��ڵ�����
		dCloneSprite("zhongpao_muban",szName);		//�����ڵ�ģ��
		dSetSpritePosition(szName,fPosX, fPosY);
		dSpriteMoveTo(szName,fPosX-100,fPosY-100,30,false);
		szName = dMakeSpriteName("xiaopao_%d", g_iNum++);		//�õ��ڵ�����
		dCloneSprite("zhongpao_muban",szName);		//�����ڵ�ģ��
		dSetSpritePosition(szName,fPosX, fPosY);
		dSpriteMoveTo(szName,fPosX+100,fPosY-100,30,false);
        }
    }
dSetSpriteLinearVelocity("zhanji", g_fSpeedLeft + g_fSpeedRight, g_fSpeedUp + g_fSpeedDown);
}
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnKeyDown(iKey, iAltPress, iShiftPress, iCtrlPress);
}
//==========================================================================
//
// ���沶׽���̵�����Ϣ�󣬽����õ�������
// ���� iKey������ļ���ֵ�� enum KeyCodes �궨��
//
void dOnKeyUp( const int iKey )
{

     /*if(iKey==KEY_W||iKey==KEY_A||iKey==KEY_S||iKey==KEY_D)
        dSetSpriteLinearVelocity("zhanji",0,0);*/
	if(g_iGameStates==2)
    {
	switch(iKey)
	{
    case KEY_W:
        g_fSpeedUp=10.f;
        break;
    case KEY_A:
        g_fSpeedLeft=10.f;
        break;
    case KEY_S:
        g_fSpeedDown=-10.f;
        break;
    case KEY_D:
        g_fSpeedRight=-10.f;
        break;
	}
	dSetSpriteLinearVelocity("zhanji", g_fSpeedLeft + g_fSpeedRight, g_fSpeedUp + g_fSpeedDown);
	}
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnKeyUp(iKey);
}

//===========================================================================
//
// ���沶׽�������뾫����ײ֮�󣬵��ô˺���
// ����֮��Ҫ������ײ�������ڱ༭�����ߴ��������þ��鷢�ͼ�������ײ
// ���� szSrcName��������ײ�ľ�������
// ���� szTarName������ײ�ľ�������
//
void dOnSpriteColSprite( const char *szSrcName, const char *szTarName )
{
	if(g_iGameStates==2)
    {
	if(strstr(szSrcName,"muban")==NULL || strstr(szTarName,"muban")==NULL )
{
//�����ײ�����ڵ��ͷɵ�
		if((strstr(szSrcName, "xiaopao")||strstr(szSrcName,"zhongpao")||strstr(szSrcName,"dapao")||strstr(szSrcName,"qiangpao"))&& strstr(szTarName,"wuzidan"))
        {
            dDeleteSprite(szSrcName);		//ɾ���ڵ�
		    dDeleteSprite(szTarName);
		    scorenum++;
        }
        if((strstr(szSrcName, "xiaopao")||strstr(szSrcName,"zhongpao")||strstr(szSrcName,"dapao")||strstr(szSrcName,"qiangpao"))&& strstr(szTarName,"youzidan"))
        {
            dDeleteSprite(szSrcName);		//ɾ���ڵ�
		    dDeleteSprite(szTarName);
		    scorenum+=2;
        }
         if(x==1)
         {
         if((strstr(szSrcName, "xiaopao")||strstr(szSrcName,"zhongpao")||strstr(szSrcName,"dapao")||strstr(szSrcName,"qiangpao"))&& strstr(szTarName,"xiaoboss"))
         {
             if(strstr(szSrcName, "xiaopao")!=NULL)
             {
                 xiaobossxue-=2;
                 scorenum+=1;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"zhongpao")!=NULL)
             {
                 xiaobossxue-=4;
                 scorenum+=2;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"dapao")!=NULL)
             {
                 xiaobossxue-=6;
                 scorenum+=3;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"qiangpao")!=NULL)
             {
                 xiaobossxue-=10;
                 scorenum+=5;
                  dDeleteSprite(szSrcName);
             }
             if(xiaobossxue<=0)
             {
                 dSetSpriteVisible("xiaoboss",false);
		         scorenum+=100;
		          x=0;
             }
         }
    }
       if(z==1)
       {
       if((strstr(szSrcName, "xiaopao")||strstr(szSrcName,"zhongpao")||strstr(szSrcName,"dapao")||strstr(szSrcName,"qiangpao"))&& strstr(szTarName,"zhongboss"))
         {
             if(strstr(szSrcName, "xiaopao")!=NULL)
             {
                 zhongbossxue-=2;
                 scorenum+=2;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"zhongpao")!=NULL)
             {
                 zhongbossxue-=4;
                 scorenum+=4;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"dapao")!=NULL)
             {
                 zhongbossxue-=6;
                 scorenum+=6;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"qiangpao")!=NULL)
             {
                zhongbossxue-=8;
                 scorenum+=5;
                  dDeleteSprite(szSrcName);
             }
             if(zhongbossxue<=0)
             {
                 dSetSpriteVisible("zhongboss",false);
		         scorenum+=300;
		         z=0;
             }
         }
       }
       if(d==1)
       {
       if((strstr(szSrcName, "xiaopao")||strstr(szSrcName,"zhongpao")||strstr(szSrcName,"dapao")||strstr(szSrcName,"qiangpao"))&& strstr(szTarName,"daboss"))
         {
             if(strstr(szSrcName, "xiaopao")!=NULL)
             {
                 dabossxue-=2;
                 scorenum+=5;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"zhongpao")!=NULL)
             {
                 dabossxue-=4;
                 scorenum+=6;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"dapao")!=NULL)
             {
                 dabossxue-=6;
                 scorenum+=7;
                  dDeleteSprite(szSrcName);
             }
             else if(strstr(szSrcName,"qiangpao")!=NULL)
             {
                 dabossxue-=10;
                 scorenum+=10;
                  dDeleteSprite(szSrcName);
             }
             if(dabossxue<=0)
             {
                dSetSpriteVisible("daboss",false);
		         scorenum+=500;
		         d=0;
		         g_iGameStates=-1;
		         dSetSpriteVisible("shengli",true);
		         dSetSpriteVisible("zhanji",false);
             }
         }
       }
       if(strstr(szSrcName, "zhanji")&&((strstr(szTarName,"xiaoboss")&&x==1)||(strstr(szTarName,"zhongboss")&&z==1)||(strstr(szTarName,"daboss")&&d==1)))
          {
              g_iGameStates=-1;
               dSetSpriteLinearVelocity("zhanji",0,0);
        fPosX = dGetSpriteLinkPointPosX("zhanji",1);
		fPosY = dGetSpriteLinkPointPosY("zhanji",1);
		 dSetSpriteVisible("zhanji",false);
            dPlayEffect("baozha", 1.0f,fPosX,fPosY,NULL);
                dSetSpriteVisible("chongxinkaishi",true);
                scorenum=0;
                g_youxishijiantime=0;
          }
    if(strstr(szSrcName, "zhanji") &&(strstr(szTarName,"difangxiaozidan")||strstr(szTarName,"difangzhongzidan")||strstr(szTarName,"difangdazidan")||strstr(szTarName,"wuzidan")||strstr(szTarName,"youzidan")))
       {
           if(g_zidandaxiao!=1)
           {
               g_zidandaxiao--;
               dDeleteSprite(szTarName);
           }
           else
           {
               g_iGameStates=-1;
               dSetSpriteLinearVelocity("zhanji",0,0);
        fPosX = dGetSpriteLinkPointPosX("zhanji",1);
		fPosY = dGetSpriteLinkPointPosY("zhanji",1);
		 dSetSpriteVisible("zhanji",false);
            dPlayEffect("baozha", 1.0f,fPosX,fPosY,NULL);
                dSetSpriteVisible("chongxinkaishi",true);
                scorenum=0;
                g_youxishijiantime=0;
           }
       }
       if(strstr(szSrcName, "zhanji")&&strstr(szTarName,"jiaqiang"))
       {
           if(g_zidandaxiao<4) g_zidandaxiao++;
           dDeleteSprite(szTarName);
       }
	}
    }
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnSpriteColSprite(szSrcName, szTarName);
}

//===========================================================================
//
// ���沶׽������������߽���ײ֮�󣬵��ô˺���.
// ����֮��Ҫ������ײ�������ڱ༭�����ߴ��������þ��������߽�����
// ���� szName����ײ���߽�ľ�������
// ���� iColSide����ײ���ı߽� 0 ��ߣ�1 �ұߣ�2 �ϱߣ�3 �±�
//
void dOnSpriteColWorldLimit( const char *szName, const int iColSide )
{
	if(strstr(szName, "zhanji") !=NULL)
{
switch(iColSide)
        {
        case 0:
        dSetSpriteLinearVelocity(szName,0,g_fSpeedUp + g_fSpeedDown);
        g_zuosudu=0;
           break;
        case 1:
        dSetSpriteLinearVelocity(szName,0,g_fSpeedUp + g_fSpeedDown);
        g_yousudu=0;
            break;
        case 2:
        dSetSpriteLinearVelocity(szName,g_fSpeedLeft + g_fSpeedRight,0);
        g_shangsudu=0;
        break;
        case 3:
        dSetSpriteLinearVelocity(szName,g_fSpeedLeft + g_fSpeedRight,0);
        g_xiasudu=0;
        break;
   }
}
if(strstr(szName,"muban")==NULL)
{
//�����������߽�Ĳ���ģ��
		if(strstr(szName,"wuzidan")!=NULL&&iColSide==3)
    {
//3��ʾ�±߽�
			dDeleteSprite(szName);
		}
		else if(strstr(szName,"youzidan")!=NULL&&iColSide==3)
    {
//3��ʾ�±߽�
			dDeleteSprite(szName);
		}
if(strstr(szName,"xiaopao")!=NULL)
     {
			dDeleteSprite(szName);
		}
    else if(strstr(szName,"zhongpao")!=NULL)
    {
        dDeleteSprite(szName);
    }
    else if(strstr(szName,"dapao")!=NULL)
    {
        dDeleteSprite(szName);
    }
    else if(strstr(szName,"qiangpao")!=NULL)
    {
        dDeleteSprite(szName);
    }
    else if(strstr(szName,"difangxiaozidan")!=NULL)
    {
         dDeleteSprite(szName);
    }
    else if(strstr(szName,"difangzhongzidan")!=NULL)
    {
         dDeleteSprite(szName);
    }
    else if(strstr(szName,"difangdazidan")!=NULL)
    {
         dDeleteSprite(szName);
    }
    else if(strstr(szName,"difangdazidan")!=NULL)
    {
         dDeleteSprite(szName);
    }
    if(strstr(szName,"xiaoboss")!=NULL&&iColSide==0)
    {
        dSetSpriteLinearVelocity("xiaoboss",10,0);
    }
    if(strstr(szName,"xiaoboss")!=NULL&&iColSide==1)
     {
         dSetSpriteLinearVelocity("xiaoboss",-10,0);
     }
     if(strstr(szName,"zhongboss")!=NULL&&iColSide==0)
    {
        dSetSpriteLinearVelocity("zhongboss",10,0);
    }
    if(strstr(szName,"zhongboss")!=NULL&&iColSide==1)
     {
         dSetSpriteLinearVelocity("zhongboss",-10,0);
     }
     if(strstr(szName,"daboss")!=NULL&&iColSide==0)
    {
        dSetSpriteLinearVelocity("daboss",10,0);
    }
    if(strstr(szName,"daboss")!=NULL&&iColSide==1)
     {
         dSetSpriteLinearVelocity("daboss",-10,0);
     }
}
	// �����ڴ�������Ϸ��Ҫ����Ӧ����
	OnSpriteColWorldLimit(szName, iColSide);
}
